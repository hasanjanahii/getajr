import React, { useState, useEffect } from 'react';

interface Dhikr {
  id: string;
  text: string;
  target: number;
  interval: number;
}

const dhikrOptions: Dhikr[] = [
  { 
    id: 'tasbih', 
    text: 'سبحان الله الحمد لله الله أكبر',
    target: 33,
    interval: 2000
  },
  { 
    id: 'tahlil', 
    text: 'لا إله إلا الله وحده لا شريك له الملك وله الحمد وهو على كل شيء قدير',
    target: 100,
    interval: 5000
  }
];

function App() {
  const [selectedDhikr, setSelectedDhikr] = useState<string>('');
  const [counter, setCounter] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  const currentDhikr = dhikrOptions.find(dhikr => dhikr.id === selectedDhikr);
  const targetCount = currentDhikr?.target || 33;

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && counter < targetCount) {
      interval = setInterval(() => {
        setCounter(prev => {
          if (prev >= targetCount - 1) {
            setIsRunning(false);
            return targetCount;
          }
          return prev + 1;
        });
      }, currentDhikr?.interval || 2000);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isRunning, counter, targetCount, currentDhikr?.interval]);

  const handleDhikrSelect = (dhikrId: string) => {
    setSelectedDhikr(dhikrId);
    setCounter(0);
    setIsRunning(true);
  };

  const handleStop = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setCounter(0);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
    }`}>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header with Dark Mode Toggle */}
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-2xl font-light tracking-wide">Get Ajr</h1>
          
          {/* Dark Mode Switch */}
          <button
              onClick={toggleDarkMode}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                isDarkMode 
                  ? 'bg-gray-600 focus:ring-gray-500' 
                  : 'bg-gray-300 focus:ring-gray-400'
              }`}
              aria-label="Toggle dark mode"
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                  isDarkMode ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
        </div>

        {/* Dhikr Selection */}
        <div className="mb-16">
          <div className="grid grid-cols-1 gap-6">
            {dhikrOptions.map((dhikr) => (
              <button
                key={dhikr.id}
                onClick={() => handleDhikrSelect(dhikr.id)}
                className={`p-6 md:p-8 rounded-lg text-xl md:text-2xl font-medium transition-all duration-200 text-center leading-relaxed max-w-2xl mx-auto w-full ${
                  selectedDhikr === dhikr.id
                    ? isDarkMode 
                      ? 'bg-gray-800 text-white'
                      : 'bg-gray-300 text-gray-900'
                    : isDarkMode
                      ? 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                      : 'text-gray-900 hover:bg-gray-100'
                }`}
                dir="rtl"
              >
                <div className="mb-3">
                  {dhikr.id === 'tahlil' ? (
                    <>
                      لا إله إلا الله وحده لا شريك له 
                      <br></br>
                      له الملك و له الحمد و هو على كل شيء قدير  
                    </>
                  ) : (
                    dhikr.text
                  )}
                </div>
                <div className={`text-sm md:text-base font-normal ${
                  selectedDhikr === dhikr.id 
                    ? 'text-gray-200' 
                    : isDarkMode 
                      ? 'text-gray-500' 
                      : 'text-gray-600'
                }`} dir="ltr">
                  {dhikr.target} times
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Counter Display */}
        {selectedDhikr && (
          <div className="text-center mb-12">
            <div className={`text-8xl md:text-9xl font-light mb-8 tabular-nums ${
              isDarkMode ? 'text-gray-100' : 'text-gray-900'
            }`}>
              {counter.toString().padStart(2, '0')}
            </div>
            
            {/* Control Buttons */}
            <div className="flex justify-center gap-4 flex-wrap">
              {!isRunning ? (
                <button
                  onClick={() => setIsRunning(true)}
                  disabled={counter >= targetCount}
                  className={`px-8 py-3 rounded-lg font-medium transition-all duration-200 ${
                    counter >= targetCount
                      ? isDarkMode
                        ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : isDarkMode
                        ? 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  Continue
                </button>
              ) : (
                <button
                  onClick={handleStop}
                  className={`px-8 py-3 rounded-lg font-medium transition-all duration-200 ${
                    isDarkMode
                      ? 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  Stop
                </button>
              )}
              
              <button
                onClick={handleReset}
                className={`px-8 py-3 rounded-lg font-medium transition-all duration-200 ${
                  isDarkMode
                    ? 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                    : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                }`}
              >
                Reset
              </button>
            </div>
          </div>
        )}

        {/* Progress Indicator */}
        {selectedDhikr && (
          <div className="mb-16">
            <div className={`w-full h-1 rounded-full ${
              isDarkMode ? 'bg-gray-800' : 'bg-gray-200'
            }`}>
              <div 
                className={`h-full rounded-full transition-all duration-300 ${
                  isDarkMode ? 'bg-gray-600' : 'bg-gray-400'
                }`}
                style={{ width: `${(counter / targetCount) * 100}%` }}
              />
            </div>
            <div className={`text-center mt-2 text-sm ${
              isDarkMode ? 'text-gray-400' : 'text-gray-600'
            }`}>
              {counter}/{targetCount}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className={`py-6 text-center border-t ${
        isDarkMode 
          ? 'border-gray-800 text-gray-400' 
          : 'border-gray-200 text-gray-600'
      }`}>
        <p className="text-sm">
          Built by{' '}
          <a 
            href="https://www.hasanjanahi.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className={`transition-colors duration-200 ${
              isDarkMode 
                ? 'text-gray-300 hover:text-white' 
                : 'text-gray-800 hover:text-black'
            }`}
          >
            Hasan Janahi
          </a>
        </p>
      </footer>
    </div>
  );
}

export default App;